function lenString() {
    var string = document.getElementById("string").value;
    var lenString = string.length;
    document.getElementById("output").innerHTML =
      "The Length of string is: " + lenString;
  }

function reverseNumber() {
    var number = document.getElementById("number").value;
    var reversedNumber = number.toString().split("").reverse().join("");
    document.getElementById("output").innerHTML =
        "The reversed number is: " + reversedNumber;
}
