function validateForm() {
    const email = document.forms["employee-form"]["email"].value;
    const name = document.forms["employee-form"]["name"].value;
    const mobile = document.forms["employee-form"]["mobile"].value;
    const address = document.forms["employee-form"]["address"].value;

    const emailRegex = /\S+@\S+\.\S+/;
    const nameRegex = /^[A-Za-z ]+$/;
    const mobileRegex = /^[0-9]{10}$/;

    if (!emailRegex.test(email)) {
        alert("Please enter a valid email address");
        return false;
    }
    if (!nameRegex.test(name)) {
        alert("Please enter a valid name (letters and spaces only)");
        return false;
    }
    if (!mobileRegex.test(mobile)) {
        alert("Please enter a valid 10 digit mobile number");
        return false;
    }
    if (address === "") {
        alert("Please enter an address");
        return false;
    }
    return true;
}