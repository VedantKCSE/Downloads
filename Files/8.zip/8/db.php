<?php
$conn = mysqli_connect("localhost","root","","sycse");
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}


if(isset($_GET['username']) && isset($_GET['password'])) { //The isset() function checks whether a variable is set,. This function returns true if the variable exists ..
    $username = $_GET['username'];
    $password = $_GET['password'];


$que= "select *from aa where uname='$username' and pass='$password' ";
$res=mysqli_query($conn,$que);

if(mysqli_num_rows($res) > 0){  
 echo "Welcome". $username . "<br>";
 echo "You have signed in successfully"  ;

}
else
	echo "Login Failed";

}

$query= "select *from vc";
$result=mysqli_query($conn,$query);
if(mysqli_num_rows($result) > 0){  
 while($row = mysqli_fetch_assoc($result)){  
    
	echo "Visitors Count : {$row['count']}  <br> ";
	
 }	

}

?>

