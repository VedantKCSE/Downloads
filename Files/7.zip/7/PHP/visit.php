<?php

$con = mysqli_connect("localhost", "root", "", "test") or die(mysqli_error());

$sql = "SELECT * FROM visitor_counter"; 
$result=mysqli_query($con, $sql);
$row = mysqli_fetch_array($result); $counter = $row['counts'];

if (empty($counter)) { 
	$counter = 1;
	$sql1 = "INSERT INTO visitor_counter (counts) VALUES ('$counter')"; 
	$result1= mysqli_query($con, $sql1);
}
echo "You 're visitors No. "; 
echo $counter;

$plus_counter = $counter+1;
$sq12 = "update visitor_counter set counts='Splus_counter"; 
$result2 = mysqli_query($con, $sq12);

mysqli_close($con); 
?>