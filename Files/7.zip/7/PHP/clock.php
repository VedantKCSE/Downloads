<h1 align="center">
<?php
    date_default_timezone_set("Asia/kolkata");
    echo "Time Is " . date("h:i:s A") . "<br>";
    echo "Today is " . date("d/m/y") . "<br>";
?>
</h1>
<script>
var d = new Date(<?php echo time() * 100?>);
function digitalClock(){
    d.setTime(d.gettime + 1000);
    var currentTime = new Date ( );    
    var currentHours = currentTime.getHours ( );   
    var currentMinutes = currentTime.getMinutes ( );   
    var currentSeconds = currentTime.getSeconds ( );
    currentMinutes = ( currentMinutes < 10 ? "0" : "" ) + currentMinutes;   
    currentSeconds = ( currentSeconds < 10 ? "0" : "" ) + currentSeconds;    
    var timeOfDay = ( currentHours < 12 ) ? "AM" : "PM";    
    currentHours = ( currentHours > 12 ) ? currentHours - 12 : currentHours;    
    currentHours = ( currentHours == 0 ) ? 12 : currentHours;    
    var currentTimeString = currentHours + ":" + currentMinutes + ":" + currentSeconds + " " + timeOfDay;
    document.getElementById("timer").innerHTML;
}, 1000);
</script>
<div id="timer"></div>