
function findPrimes() {
    var start = document.getElementById("start").value;
    var end = document.getElementById("end").value;
    var primes = [];
    for (var i = start; i <= end; i++) {
        var isPrime = true;
        for (var j = 2; j <= Math.sqrt(i); j++) {
            if (i % j === 0) {
                isPrime = false;
                break;
            }
        }
        if (isPrime) {
            primes.push(i);
        }
    }
    document.getElementById("output").innerHTML = "The prime numbers between " + start + " and " + end + " are: " + primes.join(", ");
}